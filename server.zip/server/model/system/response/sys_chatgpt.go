package response

type ChatGptResponse struct {
}
