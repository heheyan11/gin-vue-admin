package config

type Vars struct {
	LisUrl string `mapstructure:"lis-url" json:"lis-url" yaml:"lis-url"`
}
