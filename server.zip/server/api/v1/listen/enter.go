package listen

type ApiGroup struct {
	LisConfigAPi
	ApisApi
	CoinsApi
	OrderApi
}
