package ast

import (
	"testing"
)

func TestAddRouterCode(t *testing.T) {
	AddRouterCode("D:\\gin-vue-admin\\server\\utils\\ast\\ast_router_test.go", "Routers", "testRouter", "GVAStruct")
}
