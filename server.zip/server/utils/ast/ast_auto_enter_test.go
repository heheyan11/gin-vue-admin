package ast

import "testing"

func TestImportForAutoEnter(t *testing.T) {
	ImportForAutoEnter("D:\\gin-vue-admin\\server\\api\\v1\\test\\enter.go", "ApiGroup", "test")
}
