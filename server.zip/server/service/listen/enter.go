package listen

type ServiceGroup struct {
	ApisService
	CoinsService
	OrderService
}
